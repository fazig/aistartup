// Application Main JS Controller for Mobile Shop Management System

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Application State
  const state = {
    currentView: 'dashboard',
    currentUser: null,
    cart: [], // billing cart: array of { product, quantity }
    purchaseCart: [], // purchase creation cart: array of { product, quantity, cost }
    imageBuffer: null, // temporary holding base64 image data on forms
    activeScannerTarget: 'billing', // 'billing' or 'stock'
    charts: {} // cache Chart.js instances
  };

  // DOM Elements cache
  const elements = {
    // Navigation & Layout
    aside: document.getElementById('sidebar'),
    navLinks: document.querySelectorAll('.nav-links li'),
    logoutBtn: document.getElementById('btn-logout'),
    usernameEl: document.getElementById('current-username'),
    userRoleEl: document.getElementById('current-userrole'),
    views: document.querySelectorAll('.app-view'),
    
    // Auth
    loginOverlay: document.getElementById('login-overlay'),
    loginForm: document.getElementById('login-form'),
    loginError: document.getElementById('login-error'),
    
    // Dashboard Stats
    statRevenue: document.getElementById('stat-revenue'),
    statProfit: document.getElementById('stat-profit'),
    statStockValue: document.getElementById('stat-stock-value'),
    statLowStockCount: document.getElementById('stat-low-stock-count'),
    lowStockAlertBar: document.getElementById('low-stock-alert-bar'),
    lowStockAlertText: document.getElementById('low-stock-alert-text'),
    lowStockAlertBtn: document.getElementById('low-stock-alert-btn'),
    topSellingList: document.getElementById('top-selling-list'),
    
    // Product Management
    productTableBody: document.getElementById('product-table-body'),
    btnOpenAddProduct: document.getElementById('btn-open-add-product'),
    productSearch: document.getElementById('product-search'),
    productFilterType: document.getElementById('product-filter-type'),
    
    // Modals
    modalOverlay: document.getElementById('modal-overlay'),
    modalTitle: document.getElementById('modal-title'),
    modalBody: document.getElementById('modal-body-content'),
    modalFooter: document.getElementById('modal-footer-content'),
    
    // Billing (Sales)
    cartItemsContainer: document.getElementById('cart-items-container'),
    cartSubtotal: document.getElementById('cart-subtotal'),
    cartDiscountInput: document.getElementById('cart-discount'),
    cartTotal: document.getElementById('cart-total'),
    cartCustomerName: document.getElementById('customer-name'),
    cartCustomerPhone: document.getElementById('customer-phone'),
    cartBarcodeSearch: document.getElementById('billing-product-search'),
    billingProductSearch: document.getElementById('billing-product-search'),
    billingProductsGrid: document.getElementById('billing-products-grid'),
    btnCheckout: document.getElementById('btn-checkout'),
    btnClearCart: document.getElementById('btn-clear-cart'),
    
    // Purchase
    purchaseSupplierSelect: document.getElementById('purchase-supplier-select'),
    purchaseItemsTable: document.getElementById('purchase-items-table-body'),
    purchaseTotalAmount: document.getElementById('purchase-total-amount'),
    btnOpenAddPurchase: document.getElementById('btn-open-add-purchase'),
    btnOpenAddSupplier: document.getElementById('btn-open-add-supplier'),
    purchaseHistoryTable: document.getElementById('purchase-history-table-body'),
    
    // Stock Management
    stockTableBody: document.getElementById('stock-table-body'),
    stockSearch: document.getElementById('stock-search'),
    stockHistoryTable: document.getElementById('stock-history-table-body'),
    
    // Scanners
    btnOpenScanner: document.getElementById('btn-open-scanner'),
    btnOpenVirtualScanner: document.getElementById('btn-open-virtual-scanner'),
    virtualScannerPanel: document.getElementById('virtual-scanner-panel'),
    virtualScannerItems: document.getElementById('virtual-scanner-items'),
    
    // Reports
    reportMonthSales: document.getElementById('report-month-sales'),
    reportMonthProfit: document.getElementById('report-month-profit'),
    reportMonthPurchases: document.getElementById('report-month-purchases'),
    reportTopProductsTable: document.getElementById('report-top-products-body'),
    reportFilterMonth: document.getElementById('report-filter-month'),
    
    // Print Receipt
    printContainer: document.getElementById('invoice-print-container')
  };

  // ==========================================
  // VIEW ROUTER
  // ==========================================
  function switchView(viewName) {
    state.currentView = viewName;
    
    // Update navigation active status
    elements.navLinks.forEach(link => {
      if (link.dataset.view === viewName) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });

    // Toggle views
    elements.views.forEach(view => {
      if (view.id === `${viewName}-view`) {
        view.classList.add('active');
      } else {
        view.classList.remove('active');
      }
    });

    // Trigger View specific updates
    switch (viewName) {
      case 'dashboard':
        updateDashboardMetrics();
        break;
      case 'products':
        renderProductsTable();
        break;
      case 'stock':
        renderStockTable();
        renderStockHistory();
        break;
      case 'sales':
        initBillingScreen();
        break;
      case 'purchases':
        initPurchasesScreen();
        break;
      case 'reports':
        renderReportsScreen();
        break;
    }
  }

  // Setup navigation click events
  elements.navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      const view = link.dataset.view;
      if (view) {
        switchView(view);
      }
    });
  });

  // ==========================================
  // AUTHENTICATION
  // ==========================================
  function checkAuth() {
    const user = window.db.getCurrentUser();
    if (user) {
      state.currentUser = user;
      elements.usernameEl.textContent = user.username;
      elements.userRoleEl.textContent = user.role;
      elements.loginOverlay.style.display = 'none';
      switchView('dashboard');
    } else {
      elements.loginOverlay.style.display = 'flex';
    }
  }

  elements.loginForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const userVal = document.getElementById('login-username').value;
    const passVal = document.getElementById('login-password').value;
    
    const user = window.db.login(userVal, passVal);
    if (user) {
      elements.loginError.style.display = 'none';
      checkAuth();
    } else {
      elements.loginError.style.display = 'flex';
    }
  });

  elements.logoutBtn.addEventListener('click', () => {
    window.db.logout();
    state.currentUser = null;
    checkAuth();
  });

  // ==========================================
  // DASHBOARD METRICS
  // ==========================================
  function updateDashboardMetrics() {
    const sales = window.db.getSales();
    const purchases = window.db.getPurchases();
    const products = window.db.getProducts();
    const stock = window.db.getStock();

    // 1. Calculate Revenue & Profits
    let revenue = 0;
    let profit = 0;
    sales.forEach(sale => {
      revenue += sale.total;
      profit += sale.profit;
    });

    elements.statRevenue.textContent = `Rs. ${revenue.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0})}`;
    elements.statProfit.textContent = `Rs. ${profit.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0})}`;

    // 2. Stock Valuation (Cost base of currently held items)
    let stockValuation = 0;
    let lowStockCount = 0;
    const lowStockItems = [];

    products.forEach(p => {
      const qty = stock[p.id] || 0;
      stockValuation += qty * p.cost;
      
      if (qty <= p.minStock) {
        lowStockCount++;
        lowStockItems.push({ product: p, qty });
      }
    });

    elements.statStockValue.textContent = `Rs. ${stockValuation.toLocaleString(undefined, {minimumFractionDigits: 0, maximumFractionDigits: 0})}`;
    elements.statLowStockCount.textContent = lowStockCount;

    // Show Low Stock alert bar
    if (lowStockCount > 0) {
      elements.lowStockAlertBar.style.display = 'flex';
      elements.lowStockAlertText.innerHTML = `<i class="fas fa-exclamation-triangle"></i> Warning: <strong>${lowStockCount}</strong> product(s) are running low in stock!`;
      elements.lowStockAlertBtn.onclick = () => {
        switchView('stock');
        elements.stockSearch.value = '';
        renderStockTable(true); // filter low stock only
      };
    } else {
      elements.lowStockAlertBar.style.display = 'none';
    }

    // 3. Render Dashboard Top Selling Items (max 5)
    renderDashboardTopSelling();

    // 4. Render Dashboard Chart (Past 10 days sales vs purchases)
    renderDashboardCharts();
  }

  function renderDashboardTopSelling() {
    const sales = window.db.getSales();
    const products = window.db.getProducts();
    
    // Count sales per product
    const productSales = {};
    sales.forEach(sale => {
      sale.items.forEach(item => {
        productSales[item.productId] = (productSales[item.productId] || 0) + item.qty;
      });
    });

    // Sort products by sales
    const sortedProducts = products
      .map(p => ({
        product: p,
        salesCount: productSales[p.id] || 0
      }))
      .filter(item => item.salesCount > 0)
      .sort((a, b) => b.salesCount - a.salesCount)
      .slice(0, 5);

    elements.topSellingList.innerHTML = '';
    if (sortedProducts.length === 0) {
      elements.topSellingList.innerHTML = '<li class="text-muted" style="padding: 1rem; text-align: center;">No sales recorded yet.</li>';
      return;
    }

    sortedProducts.forEach(item => {
      const p = item.product;
      const li = document.createElement('li');
      li.className = 'top-selling-item';
      
      const imgUrl = p.image || `data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><rect width="100" height="100" fill="%232a2b3d"/><text x="50" y="50" dominant-baseline="middle" text-anchor="middle" font-family="sans-serif" font-size="12" fill="%23ffffff">${p.brand}</text></svg>`;

      li.innerHTML = `
        <img src="${imgUrl}" class="item-img" alt="${p.name}">
        <div class="item-info">
          <div class="item-name">${p.name}</div>
          <div class="item-sales">${p.brand} | ${p.model}</div>
        </div>
        <div style="text-align: right;">
          <div class="item-sales">Sold: <span>${item.salesCount}</span></div>
          <div class="item-sales" style="color: var(--accent-blue); font-weight:700;">Rs. ${p.price}</div>
        </div>
      `;
      elements.topSellingList.appendChild(li);
    });
  }

  function renderDashboardCharts() {
    const sales = window.db.getSales();
    const purchases = window.db.getPurchases();
    
    // Group sales and purchases by date (past 10 days)
    const dates = [];
    const salesData = [];
    const purchaseData = [];

    for (let i = 9; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
      dates.push(dateStr);

      // Sum sales for date
      const dStart = new Date(d.setHours(0,0,0,0));
      const dEnd = new Date(d.setHours(23,59,59,999));
      
      const salesOnDate = sales.filter(s => {
        const sDate = new Date(s.date);
        return sDate >= dStart && sDate <= dEnd;
      });
      const saleSum = salesOnDate.reduce((sum, s) => sum + s.total, 0);
      salesData.push(saleSum);

      // Sum purchases for date
      const purchasesOnDate = purchases.filter(p => {
        const pDate = new Date(p.date);
        return pDate >= dStart && pDate <= dEnd;
      });
      const purchaseSum = purchasesOnDate.reduce((sum, p) => sum + p.total, 0);
      purchaseData.push(purchaseSum);
    }

    if (state.charts.dashboardChart) {
      state.charts.dashboardChart.destroy();
    }

    const ctx = document.getElementById('sales-chart').getContext('2d');
    state.charts.dashboardChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: dates,
        datasets: [
          {
            label: 'Sales Revenue',
            data: salesData,
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.1)',
            tension: 0.4,
            fill: true
          },
          {
            label: 'Purchases Cost',
            data: purchaseData,
            borderColor: '#8b5cf6',
            backgroundColor: 'rgba(139, 92, 246, 0.1)',
            tension: 0.4,
            fill: true
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            labels: { color: '#94a3b8' }
          }
        },
        scales: {
          x: {
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#94a3b8' }
          },
          y: {
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#94a3b8' }
          }
        }
      }
    });
  }

  // ==========================================
  // MODAL CONTROLLER
  // ==========================================
  function openModal(title, bodyHTML, footerHTML) {
    elements.modalTitle.textContent = title;
    elements.modalBody.innerHTML = bodyHTML;
    elements.modalFooter.innerHTML = footerHTML || '';
    elements.modalOverlay.classList.add('active');
  }

  function closeModal() {
    elements.modalOverlay.classList.remove('active');
    state.imageBuffer = null;
    window.scanner.stopCameraScanner();
  }

  document.querySelectorAll('.close-modal, .btn-close-modal').forEach(btn => {
    btn.addEventListener('click', closeModal);
  });
  elements.modalOverlay.addEventListener('click', (e) => {
    if (e.target === elements.modalOverlay) closeModal();
  });

  // ==========================================
  // PRODUCT MANAGEMENT
  // ==========================================
  function renderProductsTable() {
    const products = window.db.getProducts();
    const stock = window.db.getStock();
    const query = elements.productSearch.value.toLowerCase();
    const typeFilter = elements.productFilterType.value;

    elements.productTableBody.innerHTML = '';

    const filtered = products.filter(p => {
      const matchQuery = p.name.toLowerCase().includes(query) ||
                         p.brand.toLowerCase().includes(query) ||
                         p.model.toLowerCase().includes(query) ||
                         p.barcode.toLowerCase().includes(query);
      
      const matchType = typeFilter === 'all' || p.type === typeFilter;
      return matchQuery && matchType;
    });

    if (filtered.length === 0) {
      elements.productTableBody.innerHTML = `
        <tr>
          <td colspan="7" class="text-muted" style="text-align: center; padding: 2rem;">
            No products found matching criteria.
          </td>
        </tr>
      `;
      return;
    }

    filtered.forEach(p => {
      const tr = document.createElement('tr');
      const qty = stock[p.id] || 0;
      
      // Stock warning class
      const qtyClass = qty <= p.minStock ? 'style="color: var(--accent-rose); font-weight:700;"' : '';

      tr.innerHTML = `
        <td>
          <div style="display:flex; align-items:center; gap: 0.75rem;">
            <img src="${p.image || 'https://images.unsplash.com/photo-1523206489230-c012c64b2b48?w=80&auto=format&fit=crop&q=60'}" style="width:40px; height:40px; border-radius:8px; object-fit:cover;">
            <div>
              <div style="font-weight:600;">${p.name}</div>
              <div style="font-size:0.75rem; color:var(--text-secondary);">BC: ${p.barcode}</div>
            </div>
          </div>
        </td>
        <td><span class="badge badge-${p.type}">${p.type}</span></td>
        <td>${p.brand}</td>
        <td>${p.color}</td>
        <td>${p.ram} / ${p.storage}</td>
        <td>
          <div style="font-weight:600; color:var(--accent-blue);">Rs. ${p.price}</div>
          <div style="font-size:0.75rem; color:var(--text-muted);">Cost: Rs. ${p.cost}</div>
        </td>
        <td ${qtyClass}>${qty} <span style="font-size:0.75rem; color:var(--text-muted);">(${p.minStock})</span></td>
        <td>
          <div style="display:flex; gap: 0.5rem;">
            <button class="btn btn-secondary btn-icon-only btn-edit" data-id="${p.id}"><i class="fas fa-edit"></i></button>
            <button class="btn btn-rose btn-icon-only btn-delete" data-id="${p.id}"><i class="fas fa-trash"></i></button>
          </div>
        </td>
      `;

      // Event Listeners
      tr.querySelector('.btn-edit').onclick = () => openProductForm(p);
      tr.querySelector('.btn-delete').onclick = () => confirmDeleteProduct(p);

      elements.productTableBody.appendChild(tr);
    });
  }

  elements.productSearch.addEventListener('input', renderProductsTable);
  elements.productFilterType.addEventListener('change', renderProductsTable);

  elements.btnOpenAddProduct.onclick = () => openProductForm();

  function openProductForm(product = null) {
    const isEdit = !!product;
    const title = isEdit ? `Edit Product: ${product.name}` : 'Add New Product';
    
    // Generate simple standard code for barcode if adding new device
    const defaultBarcode = isEdit ? product.barcode : Math.floor(100000000000 + Math.random() * 900000000000).toString();

    const bodyHTML = `
      <form id="product-form">
        <input type="hidden" id="p-id" value="${isEdit ? product.id : ''}">
        
        <div class="form-row">
          <div class="form-group">
            <label for="p-name">Product Name *</label>
            <input type="text" id="p-name" class="form-control" required value="${isEdit ? product.name : ''}">
          </div>
          <div class="form-group">
            <label for="p-barcode">Barcode / QR Code *</label>
            <input type="text" id="p-barcode" class="form-control" required value="${defaultBarcode}">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="p-type">Product Category *</label>
            <select id="p-type" class="form-control" required>
              <option value="new" ${isEdit && product.type === 'new' ? 'selected' : ''}>New Mobile</option>
              <option value="used" ${isEdit && product.type === 'used' ? 'selected' : ''}>Used (Old) Mobile</option>
              <option value="keypad" ${isEdit && product.type === 'keypad' ? 'selected' : ''}>Keypad Mobile</option>
              <option value="accessory" ${isEdit && product.type === 'accessory' ? 'selected' : ''}>Accessories</option>
            </select>
          </div>
          <div class="form-group">
            <label for="p-brand">Brand Name *</label>
            <input type="text" id="p-brand" class="form-control" required value="${isEdit ? product.brand : ''}" placeholder="Apple, Samsung, Anker, etc.">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="p-model">Model Name</label>
            <input type="text" id="p-model" class="form-control" value="${isEdit ? product.model : ''}">
          </div>
          <div class="form-group">
            <label for="p-color">Color</label>
            <input type="text" id="p-color" class="form-control" value="${isEdit ? product.color : ''}">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="p-ram">RAM Detail (e.g. 8GB)</label>
            <input type="text" id="p-ram" class="form-control" value="${isEdit ? product.ram : ''}">
          </div>
          <div class="form-group">
            <label for="p-storage">Storage Detail (e.g. 256GB)</label>
            <input type="text" id="p-storage" class="form-control" value="${isEdit ? product.storage : ''}">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="p-cost">Cost Price ($) *</label>
            <input type="number" step="0.01" id="p-cost" class="form-control" required value="${isEdit ? product.cost : ''}">
          </div>
          <div class="form-group">
            <label for="p-price">Selling Price ($) *</label>
            <input type="number" step="0.01" id="p-price" class="form-control" required value="${isEdit ? product.price : ''}">
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label for="p-minStock">Low Stock Alert Threshold *</label>
            <input type="number" id="p-minStock" class="form-control" required value="${isEdit ? product.minStock : '5'}">
          </div>
          <div class="form-group">
            <label>Product Image</label>
            <div class="image-upload-wrapper" id="img-upload-widget">
              <i class="fas fa-cloud-upload-alt" id="img-upload-icon"></i>
              <span id="img-upload-text" style="font-size:0.85rem; color:var(--text-secondary);">Click to upload image</span>
              <input type="file" id="p-image-file" accept="image/*" style="display:none;">
              <img id="img-upload-preview" class="image-upload-preview" src="${isEdit && product.image ? product.image : ''}" style="${isEdit && product.image ? 'display:block;' : 'display:none;'}">
            </div>
          </div>
        </div>
      </form>
    `;

    const footerHTML = `
      <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" id="btn-save-product">Save Product</button>
    `;

    openModal(title, bodyHTML, footerHTML);

    // Setup photo upload handler
    const fileInput = document.getElementById('p-image-file');
    const uploadWidget = document.getElementById('img-upload-widget');
    const preview = document.getElementById('img-upload-preview');
    const icon = document.getElementById('img-upload-icon');
    const txt = document.getElementById('img-upload-text');

    uploadWidget.onclick = () => fileInput.click();

    fileInput.onchange = (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          state.imageBuffer = event.target.result;
          preview.src = state.imageBuffer;
          preview.style.display = 'block';
          icon.style.display = 'none';
          txt.style.display = 'none';
        };
        reader.readAsDataURL(file);
      }
    };

    if (isEdit && product.image) {
      state.imageBuffer = product.image;
      preview.style.display = 'block';
      icon.style.display = 'none';
      txt.style.display = 'none';
    }

    // Save Action
    document.getElementById('btn-save-product').onclick = () => {
      const form = document.getElementById('product-form');
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      const pData = {
        id: document.getElementById('p-id').value || undefined,
        name: document.getElementById('p-name').value,
        barcode: document.getElementById('p-barcode').value,
        type: document.getElementById('p-type').value,
        brand: document.getElementById('p-brand').value,
        model: document.getElementById('p-model').value || 'N/A',
        color: document.getElementById('p-color').value || 'N/A',
        ram: document.getElementById('p-ram').value || 'N/A',
        storage: document.getElementById('p-storage').value || 'N/A',
        cost: parseFloat(document.getElementById('p-cost').value),
        price: parseFloat(document.getElementById('p-price').value),
        minStock: parseInt(document.getElementById('p-minStock').value),
        image: state.imageBuffer
      };

      window.db.saveProduct(pData);
      closeModal();
      renderProductsTable();
    };
  }

  function confirmDeleteProduct(product) {
    const title = 'Confirm Delete';
    const bodyHTML = `
      <p>Are you sure you want to delete product <strong>${product.name}</strong>?</p>
      <p class="text-muted" style="font-size:0.85rem; margin-top:0.5rem;">Warning: This will also remove its stock metrics. This cannot be undone.</p>
    `;
    const footerHTML = `
      <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn btn-rose" id="btn-confirm-delete">Delete</button>
    `;
    openModal(title, bodyHTML, footerHTML);

    document.getElementById('btn-confirm-delete').onclick = () => {
      window.db.deleteProduct(product.id);
      closeModal();
      renderProductsTable();
    };
  }

  // ==========================================
  // STOCK MANAGEMENT
  // ==========================================
  function renderStockTable(onlyLowStock = false) {
    const products = window.db.getProducts();
    const stock = window.db.getStock();
    const query = elements.stockSearch.value.toLowerCase();

    elements.stockTableBody.innerHTML = '';

    const filtered = products.filter(p => {
      const matchQuery = p.name.toLowerCase().includes(query) ||
                         p.brand.toLowerCase().includes(query) ||
                         p.barcode.toLowerCase().includes(query);
      const qty = stock[p.id] || 0;
      const matchLow = !onlyLowStock || qty <= p.minStock;
      
      return matchQuery && matchLow;
    });

    if (filtered.length === 0) {
      elements.stockTableBody.innerHTML = `
        <tr>
          <td colspan="5" class="text-muted" style="text-align: center; padding: 2rem;">
            No stock records match filters.
          </td>
        </tr>
      `;
      return;
    }

    filtered.forEach(p => {
      const tr = document.createElement('tr');
      const qty = stock[p.id] || 0;
      const isLow = qty <= p.minStock;

      tr.innerHTML = `
        <td>
          <div style="font-weight:600;">${p.name}</div>
          <div style="font-size:0.75rem; color:var(--text-secondary);">BC: ${p.barcode}</div>
        </td>
        <td><span class="badge badge-${p.type}">${p.type}</span></td>
        <td>
          <span style="font-weight: 700; font-size: 1.1rem; ${isLow ? 'color: var(--accent-rose);' : 'color: var(--accent-emerald);'}">
            ${qty}
          </span>
        </td>
        <td>${p.minStock}</td>
        <td>
          <div style="display:flex; gap: 0.5rem;">
            <button class="btn btn-secondary btn-icon-only btn-stock-adjust" data-id="${p.id}" title="Manual Adjustment"><i class="fas fa-exchange-alt"></i></button>
          </div>
        </td>
      `;

      tr.querySelector('.btn-stock-adjust').onclick = () => openStockAdjustForm(p);
      elements.stockTableBody.appendChild(tr);
    });
  }

  elements.stockSearch.addEventListener('input', () => renderStockTable(false));

  function renderStockHistory() {
    const history = window.db.getStockHistory();
    const products = window.db.getProducts();

    elements.stockHistoryTable.innerHTML = '';

    // Sort history by date descending
    const sorted = [...history].sort((a,b) => new Date(b.date) - new Date(a.date));

    if (sorted.length === 0) {
      elements.stockHistoryTable.innerHTML = `
        <tr>
          <td colspan="5" class="text-muted" style="text-align: center; padding: 1.5rem;">
            No stock transactions recorded.
          </td>
        </tr>
      `;
      return;
    }

    sorted.forEach(item => {
      const p = products.find(prod => prod.id === item.productId);
      const pName = p ? p.name : 'Unknown Product';
      const tr = document.createElement('tr');
      
      const badgeClass = item.type === 'in' ? 'badge-in' : 'badge-out';

      tr.innerHTML = `
        <td>${new Date(item.date).toLocaleString()}</td>
        <td>${pName}</td>
        <td><span class="badge ${badgeClass}">${item.type}</span></td>
        <td style="font-weight:600;">${item.qty}</td>
        <td><span style="font-size:0.85rem; color:var(--text-secondary);">${item.source} (${item.notes || 'N/A'})</span></td>
      `;
      elements.stockHistoryTable.appendChild(tr);
    });
  }

  function openStockAdjustForm(product) {
    const currentQty = window.db.getStockQuantity(product.id);
    const title = `Stock Adjustment: ${product.name}`;
    
    const bodyHTML = `
      <form id="stock-adjust-form">
        <p style="margin-bottom:1rem;">Current Quantity: <strong style="color:var(--accent-blue); font-size:1.2rem;">${currentQty}</strong></p>
        
        <div class="form-group">
          <label for="sa-type">Adjustment Type *</label>
          <select id="sa-type" class="form-control" required>
            <option value="in">Add Stock (+)</option>
            <option value="out">Remove Stock (-)</option>
          </select>
        </div>

        <div class="form-group">
          <label for="sa-qty">Quantity *</label>
          <input type="number" id="sa-qty" class="form-control" min="1" required value="1">
        </div>

        <div class="form-group">
          <label for="sa-notes">Notes / Reason *</label>
          <input type="text" id="sa-notes" class="form-control" required placeholder="e.g. Broken screen write-off, manual check audit">
        </div>
      </form>
    `;

    const footerHTML = `
      <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" id="btn-save-stock-adjust">Apply</button>
    `;

    openModal(title, bodyHTML, footerHTML);

    document.getElementById('btn-save-stock-adjust').onclick = () => {
      const form = document.getElementById('stock-adjust-form');
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      const type = document.getElementById('sa-type').value;
      const qty = parseInt(document.getElementById('sa-qty').value);
      const notes = document.getElementById('sa-notes').value;

      window.db.logStockTransaction(product.id, type, qty, 'adjustment', notes);
      closeModal();
      renderStockTable();
      renderStockHistory();
    };
  }

  // ==========================================
  // SALES / BILLING SYSTEM
  // ==========================================
  function initBillingScreen() {
    state.cart = [];
    renderCart();
    renderBillingProducts();
    elements.cartCustomerName.value = '';
    elements.cartCustomerPhone.value = '';
    elements.cartDiscountInput.value = '0';
  }

  function renderBillingProducts() {
    const products = window.db.getProducts();
    const stock = window.db.getStock();
    const query = elements.billingProductSearch.value.trim().toLowerCase();

    elements.billingProductsGrid.innerHTML = '';

    if (!query) {
      elements.billingProductsGrid.innerHTML = `
        <div class="search-placeholder-msg" style="grid-column: 1/-1; text-align: center; padding: 5rem 2rem; color: var(--text-muted); display: flex; flex-direction: column; align-items: center; gap: 1.25rem;">
          <i class="fas fa-search" style="font-size: 3.5rem; color: rgba(255, 255, 255, 0.04);"></i>
          <div style="font-size: 1.05rem; font-weight: 500; max-width: 320px; line-height: 1.5;">Type product name, brand, model or scan barcode to display suggestions...</div>
        </div>
      `;
      return;
    }

    const filtered = products.filter(p => 
      p.name.toLowerCase().includes(query) ||
      p.brand.toLowerCase().includes(query) ||
      p.barcode.toLowerCase().includes(query)
    );

    if (filtered.length === 0) {
      elements.billingProductsGrid.innerHTML = '<div class="text-muted" style="grid-column: 1/-1; text-align: center; padding: 2rem;">No matching products.</div>';
      return;
    }

    filtered.forEach(p => {
      const div = document.createElement('div');
      div.className = 'product-billing-card';
      
      const qty = stock[p.id] || 0;
      const isLow = qty <= p.minStock;
      const stockBadge = qty === 0 
        ? '<span class="prod-bill-stock low">Out of Stock</span>' 
        : `<span class="prod-bill-stock ${isLow ? 'low' : 'ok'}">Stock: ${qty}</span>`;

      div.innerHTML = `
        <img class="prod-bill-img" src="${p.image || 'https://images.unsplash.com/photo-1523206489230-c012c64b2b48?w=80&auto=format&fit=crop&q=60'}">
        <div class="prod-bill-name" title="${p.name}">${p.name}</div>
        <div class="prod-bill-meta">
          <span class="prod-bill-price">Rs. ${p.price}</span>
          ${stockBadge}
        </div>
      `;

      // Click to add to cart
      div.onclick = () => {
        if (qty <= 0) {
          alert('Cannot add to bill: Product is Out of Stock!');
          return;
        }
        addToCart(p);
      };

      elements.billingProductsGrid.appendChild(div);
    });
  }

  elements.billingProductSearch.addEventListener('input', renderBillingProducts);

  function addToCart(product) {
    const stockQty = window.db.getStockQuantity(product.id);
    const existing = state.cart.find(item => item.product.id === product.id);

    if (existing) {
      if (existing.quantity >= stockQty) {
        alert(`Cannot add more. Only ${stockQty} items available in stock.`);
        return;
      }
      existing.quantity++;
    } else {
      state.cart.push({ product, quantity: 1 });
    }

    renderCart();
  }

  function renderCart() {
    elements.cartItemsContainer.innerHTML = '';
    
    if (state.cart.length === 0) {
      elements.cartItemsContainer.innerHTML = '<div class="text-muted" style="text-align: center; padding: 3rem 0;">Cart is empty. Click items on the right or scan barcodes to begin billing.</div>';
      updateCartTotals();
      return;
    }

    state.cart.forEach((item, idx) => {
      const p = item.product;
      const row = document.createElement('div');
      row.className = 'cart-item';
      
      row.innerHTML = `
        <div class="cart-item-details">
          <div class="cart-item-title">${p.name}</div>
          <div style="font-size:0.8rem; color:var(--text-secondary); margin-top:0.2rem;">Price: Rs. ${p.price}</div>
        </div>
        <div class="cart-qty-control">
          <button class="cart-qty-btn btn-minus" data-idx="${idx}"><i class="fas fa-minus"></i></button>
          <span style="font-weight:600; min-width:20px; text-align:center;">${item.quantity}</span>
          <button class="cart-qty-btn btn-plus" data-idx="${idx}"><i class="fas fa-plus"></i></button>
        </div>
        <div style="font-weight:700; min-width:60px; text-align:right;">
          Rs. ${(p.price * item.quantity).toFixed(0)}
        </div>
        <button class="btn btn-rose btn-icon-only btn-remove" data-idx="${idx}" style="width:28px; height:28px; border-radius:6px; font-size:0.8rem;"><i class="fas fa-trash"></i></button>
      `;

      // Bind actions
      row.querySelector('.btn-minus').onclick = () => changeCartQty(idx, -1);
      row.querySelector('.btn-plus').onclick = () => changeCartQty(idx, 1);
      row.querySelector('.btn-remove').onclick = () => removeCartItem(idx);

      elements.cartItemsContainer.appendChild(row);
    });

    updateCartTotals();
  }

  function changeCartQty(idx, amount) {
    const item = state.cart[idx];
    const stockQty = window.db.getStockQuantity(item.product.id);
    const newQty = item.quantity + amount;

    if (newQty <= 0) {
      removeCartItem(idx);
      return;
    }

    if (newQty > stockQty) {
      alert(`Cannot add more. Only ${stockQty} items available in stock.`);
      return;
    }

    item.quantity = newQty;
    renderCart();
  }

  function removeCartItem(idx) {
    state.cart.splice(idx, 1);
    renderCart();
  }

  function updateCartTotals() {
    let subtotal = 0;
    state.cart.forEach(item => {
      subtotal += item.product.price * item.quantity;
    });

    const discount = parseFloat(elements.cartDiscountInput.value) || 0;
    const total = Math.max(0, subtotal - discount);

    elements.cartSubtotal.textContent = `Rs. ${subtotal.toFixed(0)}`;
    elements.cartTotal.textContent = `Rs. ${total.toFixed(0)}`;
  }

  elements.cartDiscountInput.addEventListener('input', updateCartTotals);

  elements.btnClearCart.onclick = () => {
    if (confirm('Clear entire cart?')) {
      state.cart = [];
      renderCart();
    }
  };

  // Checkout (Invoice generation)
  elements.btnCheckout.onclick = () => {
    if (state.cart.length === 0) {
      alert('Cart is empty!');
      return;
    }

    const cName = elements.cartCustomerName.value || 'Walking Customer';
    const cPhone = elements.cartCustomerPhone.value || 'N/A';
    const discount = parseFloat(elements.cartDiscountInput.value) || 0;

    // Call DB invoice handler
    const sale = window.db.createInvoice(cName, cPhone, state.cart, discount);

    // Show Invoice print review
    showReceiptModal(sale);

    // Reset billing state
    initBillingScreen();
  };

  function showReceiptModal(sale) {
    const title = `Invoice Generated: ${sale.id}`;
    
    let itemsHTML = '';
    const products = window.db.getProducts();

    sale.items.forEach(item => {
      const p = products.find(prod => prod.id === item.productId);
      const name = p ? p.name : 'Unknown Product';
      itemsHTML += `
        <tr style="border-bottom: 1px dotted #ccc;">
          <td style="padding: 4px 0; font-size: 11px;">${name}</td>
          <td style="padding: 4px 0; font-size: 11px; text-align: center;">${item.qty}</td>
          <td style="padding: 4px 0; font-size: 11px; text-align: right;">Rs. ${item.price}</td>
          <td style="padding: 4px 0; font-size: 11px; text-align: right;">Rs. ${(item.price * item.qty).toFixed(0)}</td>
        </tr>
      `;
    });

    const receiptBodyHTML = `
      <div id="receipt-print-area" style="background: white; color: black; padding: 20px; font-family: 'Courier New', monospace; max-width: 300px; margin: 0 auto; border: 1px solid #ddd; box-shadow: 0 4px 10px rgba(0,0,0,0.1); border-radius: 4px;">
        <div style="text-align: center; margin-bottom: 15px;">
          <h2 style="font-weight: 800; font-size: 16px; margin: 0 0 2px 0; letter-spacing: 1px; color: black;">FAIZAN KI SHOP</h2>
          <p style="font-size: 10px; margin: 0 0 4px 0; color: #555;">Premium Mobile & Accessories Hub</p>
          <p style="font-size: 9px; margin: 0; color: #777;">Karachi Mobile Market, Shop #4</p>
          <p style="font-size: 9px; margin: 0; color: #777;">Phone: 0300-1234567</p>
        </div>
        
        <div style="font-size: 10px; border-top: 1px dashed black; border-bottom: 1px dashed black; padding: 6px 0; margin-bottom: 10px; line-height: 14px;">
          <div><strong>Invoice #:</strong> ${sale.id}</div>
          <div><strong>Date:</strong> ${new Date(sale.date).toLocaleString()}</div>
          <div><strong>Customer:</strong> ${sale.customerName}</div>
          <div><strong>Phone:</strong> ${sale.customerPhone}</div>
        </div>

        <table style="width: 100%; border-collapse: collapse; margin-bottom: 10px;">
          <thead>
            <tr style="border-bottom: 1px dashed black;">
              <th style="padding-bottom: 4px; font-size: 11px; text-align: left; font-weight: bold;">Item</th>
              <th style="padding-bottom: 4px; font-size: 11px; text-align: center; font-weight: bold;">Qty</th>
              <th style="padding-bottom: 4px; font-size: 11px; text-align: right; font-weight: bold;">Rate</th>
              <th style="padding-bottom: 4px; font-size: 11px; text-align: right; font-weight: bold;">Amount</th>
            </tr>
          </thead>
          <tbody>
            ${itemsHTML}
          </tbody>
        </table>

        <div style="border-top: 1px dashed black; padding-top: 6px; font-size: 11px; text-align: right; line-height: 16px;">
          <div>Subtotal: Rs. ${sale.subtotal.toFixed(0)}</div>
          <div>Discount: -Rs. ${sale.discount.toFixed(0)}</div>
          <div style="font-size: 13px; font-weight: bold; margin-top: 4px; border-top: 1px dotted black; padding-top: 4px;">Grand Total: Rs. ${sale.total.toFixed(0)}</div>
        </div>

        <!-- Simulated Barcode -->
        <div style="text-align: center; margin-top: 20px; display: flex; flex-direction: column; align-items: center;">
          <svg style="width: 160px; height: 35px;" xmlns="http://www.w3.org/2000/svg">
            <rect x="0" width="3" height="30" fill="black"/>
            <rect x="5" width="1" height="30" fill="black"/>
            <rect x="8" width="2" height="30" fill="black"/>
            <rect x="12" width="4" height="30" fill="black"/>
            <rect x="18" width="1" height="30" fill="black"/>
            <rect x="21" width="3" height="30" fill="black"/>
            <rect x="26" width="2" height="30" fill="black"/>
            <rect x="30" width="1" height="30" fill="black"/>
            <rect x="33" width="4" height="30" fill="black"/>
            <rect x="39" width="2" height="30" fill="black"/>
            <rect x="43" width="3" height="30" fill="black"/>
            <rect x="48" width="1" height="30" fill="black"/>
            <rect x="51" width="2" height="30" fill="black"/>
            <rect x="55" width="4" height="30" fill="black"/>
            <rect x="61" width="1" height="30" fill="black"/>
            <rect x="64" width="3" height="30" fill="black"/>
            <rect x="69" width="2" height="30" fill="black"/>
            <rect x="73" width="1" height="30" fill="black"/>
            <rect x="76" width="4" height="30" fill="black"/>
            <rect x="82" width="2" height="30" fill="black"/>
            <rect x="86" width="3" height="30" fill="black"/>
            <rect x="91" width="1" height="30" fill="black"/>
            <rect x="94" width="2" height="30" fill="black"/>
            <rect x="98" width="4" height="30" fill="black"/>
            <rect x="104" width="1" height="30" fill="black"/>
            <rect x="107" width="3" height="30" fill="black"/>
            <rect x="112" width="2" height="30" fill="black"/>
            <rect x="116" width="1" height="30" fill="black"/>
            <rect x="119" width="4" height="30" fill="black"/>
            <rect x="125" width="2" height="30" fill="black"/>
            <rect x="129" width="3" height="30" fill="black"/>
            <rect x="134" width="1" height="30" fill="black"/>
            <rect x="137" width="2" height="30" fill="black"/>
            <rect x="141" width="4" height="30" fill="black"/>
            <rect x="147" width="1" height="30" fill="black"/>
            <rect x="150" width="3" height="30" fill="black"/>
            <rect x="155" width="2" height="30" fill="black"/>
          </svg>
          <div style="font-size: 8px; font-family: monospace; letter-spacing: 2px; margin-top: 2px;">*${sale.id}*</div>
        </div>
        
        <div style="text-align: center; font-size: 9px; margin-top: 15px; color: #555; border-top: 1px dotted black; padding-top: 8px;">
          <p style="margin: 0 0 2px 0;">Thank you for shopping with us!</p>
          <p style="margin: 0; font-weight: bold; color: black;">Software: FaizanKiShop</p>
        </div>
      </div>
    `;

    openModal(title, receiptBodyHTML, `
      <button class="btn btn-secondary" onclick="closeModal()">Close</button>
      <button class="btn btn-primary" id="btn-print-receipt"><i class="fas fa-print"></i> Print Receipt</button>
    `);

    // Print event binder
    document.getElementById('btn-print-receipt').onclick = () => {
      elements.printContainer.innerHTML = document.getElementById('receipt-print-area').outerHTML;
      window.print();
    };
  }

  // ==========================================
  // PURCHASE & SUPPLIER SYSTEM
  // ==========================================
  function initPurchasesScreen() {
    state.purchaseCart = [];
    renderPurchaseCart();
    renderPurchaseHistory();
    populateSuppliersDropdown();
  }

  function populateSuppliersDropdown() {
    const suppliers = window.db.getSuppliers();
    elements.purchaseSupplierSelect.innerHTML = '<option value="">-- Select Supplier --</option>';
    
    suppliers.forEach(supp => {
      const opt = document.createElement('option');
      opt.value = supp.id;
      opt.textContent = `${supp.name} (${supp.phone})`;
      elements.purchaseSupplierSelect.appendChild(opt);
    });
  }

  elements.btnOpenAddSupplier.onclick = () => {
    const title = 'Add New Supplier';
    const bodyHTML = `
      <form id="supplier-form">
        <div class="form-group">
          <label for="supp-name">Supplier Name *</label>
          <input type="text" id="supp-name" class="form-control" required placeholder="e.g. Mobile Tech Wholesalers">
        </div>
        <div class="form-group">
          <label for="supp-contact">Contact Person</label>
          <input type="text" id="supp-contact" class="form-control" placeholder="e.g. Asif Raza">
        </div>
        <div class="form-group">
          <label for="supp-phone">Phone Number *</label>
          <input type="text" id="supp-phone" class="form-control" required placeholder="e.g. 03211234567">
        </div>
      </form>
    `;

    const footerHTML = `
      <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" id="btn-save-supplier">Save Supplier</button>
    `;

    openModal(title, bodyHTML, footerHTML);

    document.getElementById('btn-save-supplier').onclick = () => {
      const form = document.getElementById('supplier-form');
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      const sData = {
        name: document.getElementById('supp-name').value,
        contact: document.getElementById('supp-contact').value || 'N/A',
        phone: document.getElementById('supp-phone').value
      };

      window.db.saveSupplier(sData);
      closeModal();
      populateSuppliersDropdown();
    };
  };

  elements.btnOpenAddPurchase.onclick = () => {
    const products = window.db.getProducts();
    
    const title = 'Add Product to Purchase Entry';
    const bodyHTML = `
      <form id="purchase-item-form">
        <div class="form-group">
          <label for="pi-product">Select Product *</label>
          <select id="pi-product" class="form-control" required>
            <option value="">-- Choose Product --</option>
            ${products.map(p => `<option value="${p.id}">${p.name} (BC: ${p.barcode})</option>`).join('')}
          </select>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label for="pi-qty">Quantity to Buy *</label>
            <input type="number" id="pi-qty" class="form-control" min="1" required value="1">
          </div>
          <div class="form-group">
            <label for="pi-cost">Buying Cost per Unit (Rs.) *</label>
            <input type="number" step="0.01" id="pi-cost" class="form-control" required>
          </div>
        </div>
      </form>
    `;

    const footerHTML = `
      <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
      <button class="btn btn-primary" id="btn-add-pi">Add to Bill</button>
    `;

    openModal(title, bodyHTML, footerHTML);

    // Auto populate unit cost from product cost when selected
    const prodSelect = document.getElementById('pi-product');
    prodSelect.onchange = () => {
      const pId = prodSelect.value;
      const prod = products.find(p => p.id === pId);
      if (prod) {
        document.getElementById('pi-cost').value = prod.cost;
      }
    };

    document.getElementById('btn-add-pi').onclick = () => {
      const form = document.getElementById('purchase-item-form');
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }

      const pId = prodSelect.value;
      const qty = parseInt(document.getElementById('pi-qty').value);
      const cost = parseFloat(document.getElementById('pi-cost').value);

      const prod = products.find(p => p.id === pId);
      
      // Add to state purchaseCart
      const existing = state.purchaseCart.find(item => item.productId === pId);
      if (existing) {
        existing.qty = qty;
        existing.cost = cost;
      } else {
        state.purchaseCart.push({ productId: pId, name: prod.name, qty, cost });
      }

      closeModal();
      renderPurchaseCart();
    };
  };

  function renderPurchaseCart() {
    elements.purchaseItemsTable.innerHTML = '';
    
    if (state.purchaseCart.length === 0) {
      elements.purchaseItemsTable.innerHTML = `
        <tr>
          <td colspan="5" class="text-muted" style="text-align: center; padding: 1.5rem;">
            No items added. Click "Add Product" above to build receipt.
          </td>
        </tr>
      `;
      elements.purchaseTotalAmount.textContent = 'Rs. 0';
      return;
    }

    let grandTotal = 0;
    state.purchaseCart.forEach((item, idx) => {
      const lineTotal = item.qty * item.cost;
      grandTotal += lineTotal;

      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${item.name}</td>
        <td>Rs. ${item.cost.toFixed(0)}</td>
        <td>${item.qty}</td>
        <td>Rs. ${lineTotal.toFixed(0)}</td>
        <td>
          <button class="btn btn-rose btn-icon-only btn-remove-pi" data-idx="${idx}" style="width:28px; height:28px; border-radius:6px; font-size:0.8rem;"><i class="fas fa-trash"></i></button>
        </td>
      `;

      tr.querySelector('.btn-remove-pi').onclick = () => {
        state.purchaseCart.splice(idx, 1);
        renderPurchaseCart();
      };

      elements.purchaseItemsTable.appendChild(tr);
    });

    elements.purchaseTotalAmount.textContent = `Rs. ${grandTotal.toFixed(0)}`;
  }

  // Submit Purchase Receipt
  document.getElementById('btn-submit-purchase').onclick = () => {
    const suppId = elements.purchaseSupplierSelect.value;
    if (!suppId) {
      alert('Please select a Supplier first!');
      return;
    }

    if (state.purchaseCart.length === 0) {
      alert('Please add at least one product item to the purchase invoice.');
      return;
    }

    window.db.createPurchase(suppId, state.purchaseCart);
    alert('Stock Purchase order logged successfully. Inventory updated.');
    
    // Clear state
    initPurchasesScreen();
  };

  function renderPurchaseHistory() {
    const purchases = window.db.getPurchases();
    const suppliers = window.db.getSuppliers();
    
    elements.purchaseHistoryTable.innerHTML = '';
    
    // Sort purchase history descending by date
    const sorted = [...purchases].sort((a,b) => new Date(b.date) - new Date(a.date));

    if (sorted.length === 0) {
      elements.purchaseHistoryTable.innerHTML = `
        <tr>
          <td colspan="4" class="text-muted" style="text-align: center; padding: 1.5rem;">
            No purchase records found.
          </td>
        </tr>
      `;
      return;
    }

    sorted.forEach(p => {
      const tr = document.createElement('tr');
      const supplier = suppliers.find(s => s.id === p.supplierId);
      const sName = supplier ? supplier.name : 'Unknown Supplier';

      tr.innerHTML = `
        <td>${new Date(p.date).toLocaleString()}</td>
        <td>${p.id}</td>
        <td>${sName}</td>
        <td style="font-weight:700; color:var(--accent-emerald);">Rs. ${p.total.toLocaleString(undefined, {minimumFractionDigits:0})}</td>
      `;
      elements.purchaseHistoryTable.appendChild(tr);
    });
  }

  // ==========================================
  // BARCODE & QR SCANNER ACTIONS
  // ==========================================
  elements.btnOpenScanner.onclick = () => {
    state.activeScannerTarget = state.currentView === 'stock' ? 'stock' : 'billing';
    openCameraScannerModal();
  };

  const quickScanBtn = document.getElementById('btn-scan-camera-quick');
  if (quickScanBtn) {
    quickScanBtn.onclick = () => {
      state.activeScannerTarget = 'billing';
      openCameraScannerModal();
    };
  }

  function openCameraScannerModal() {
    const title = 'Camera Barcode Scanner';
    const bodyHTML = `
      <p style="font-size:0.85rem; color:var(--text-secondary); margin-bottom:1rem; text-align:center;">Hold barcode/QR up to the camera to scan automatically.</p>
      <div id="camera-scanner-view" style="width:100%; max-width:400px; height:250px; background:black; margin:0 auto; border-radius:12px; overflow:hidden; border:2px solid var(--accent-blue);"></div>
    `;
    const footerHTML = `
      <button class="btn btn-secondary" onclick="closeModal()">Cancel</button>
    `;

    openModal(title, bodyHTML, footerHTML);
    
    // Initialize html5-qrcode camera scanning
    setTimeout(() => {
      window.scanner.initCameraScanner('camera-scanner-view', (barcode) => {
        handleBarcodeScanned(barcode);
        closeModal();
      });
    }, 300);
  }

  // Virtual simulator panel toggle
  elements.btnOpenVirtualScanner.onclick = () => {
    if (elements.virtualScannerPanel.style.display === 'block') {
      elements.virtualScannerPanel.style.display = 'none';
    } else {
      elements.virtualScannerPanel.style.display = 'block';
      renderVirtualScannerItems();
    }
  };

  function renderVirtualScannerItems() {
    const products = window.db.getProducts();
    elements.virtualScannerItems.innerHTML = '';
    
    products.forEach(p => {
      const btn = document.createElement('div');
      btn.className = 'virtual-scan-item';
      btn.textContent = `${p.brand} ${p.model}`;
      btn.onclick = () => {
        state.activeScannerTarget = state.currentView === 'stock' ? 'stock' : 'billing';
        window.scanner.simulateScan(p.barcode);
      };
      elements.virtualScannerItems.appendChild(btn);
    });
  }

  // Barcode search inputs
  elements.cartBarcodeSearch.onkeypress = (e) => {
    if (e.key === 'Enter') {
      const code = elements.cartBarcodeSearch.value.trim();
      if (code) {
        const products = window.db.getProducts();
        const match = products.find(p => p.barcode === code);
        if (match) {
          handleBarcodeScanned(code);
          elements.cartBarcodeSearch.value = '';
          renderBillingProducts();
        } else {
          // If it looks like a barcode (primarily numeric/longer digits)
          if (/^\d+$/.test(code) || code.length > 5) {
            alert(`Barcode "${code}" not found in systems. Go to Products page to register it.`);
          }
        }
      }
    }
  };

  // Central handler when barcode is identified
  function handleBarcodeScanned(barcode) {
    const products = window.db.getProducts();
    const match = products.find(p => p.barcode === barcode);

    if (!match) {
      alert(`Barcode ${barcode} not found in systems. Go to Products page to register it.`);
      return;
    }

    if (state.activeScannerTarget === 'billing') {
      // Fast Billing Flow: Add to cart directly
      const qty = window.db.getStockQuantity(match.id);
      if (qty <= 0) {
        alert(`Cannot add ${match.name}: Out of Stock!`);
        return;
      }
      addToCart(match);
      console.log(`Billed via scanner: ${match.name}`);
    } else if (state.activeScannerTarget === 'stock') {
      // Stock Adjustment Flow: Open Stock update form
      openStockAdjustForm(match);
      console.log(`Update Stock via scanner: ${match.name}`);
    }
  }

  // ==========================================
  // REPORTS DASHBOARD
  // ==========================================
  function renderReportsScreen() {
    const sales = window.db.getSales();
    const purchases = window.db.getPurchases();
    const products = window.db.getProducts();
    const stock = window.db.getStock();

    // 1. Calculate Monthly figures for header
    let totalSalesVal = 0;
    let totalProfitVal = 0;
    let totalPurchasesVal = 0;

    const filterVal = elements.reportFilterMonth.value; // e.g. "2026-06"
    
    const filteredSales = sales.filter(s => s.date.startsWith(filterVal));
    const filteredPurchases = purchases.filter(p => p.date.startsWith(filterVal));

    filteredSales.forEach(s => {
      totalSalesVal += s.total;
      totalProfitVal += s.profit;
    });

    filteredPurchases.forEach(p => {
      totalPurchasesVal += p.total;
    });

    elements.reportMonthSales.textContent = `Rs. ${totalSalesVal.toLocaleString(undefined, {minimumFractionDigits: 0})}`;
    elements.reportMonthProfit.textContent = `Rs. ${totalProfitVal.toLocaleString(undefined, {minimumFractionDigits: 0})}`;
    elements.reportMonthPurchases.textContent = `Rs. ${totalPurchasesVal.toLocaleString(undefined, {minimumFractionDigits: 0})}`;

    // 2. Generate Chart Reports
    // A. Profit vs Revenue Monthly Line Chart
    renderMonthlyPerformanceChart(filteredSales, filteredPurchases, filterVal);

    // B. Remaining Stock Doughnut Chart (New, Used, Keypad, Accessories)
    renderCategoryStockChart(products, stock);

    // C. Top Selling Products bar chart
    renderTopSellingChart(filteredSales, products);

    // 3. Render Top Selling Products Table list
    renderTopSellingReportTable(filteredSales, products);
  }

  elements.reportFilterMonth.addEventListener('change', renderReportsScreen);

  function renderMonthlyPerformanceChart(sales, purchases, filterMonth) {
    const year = parseInt(filterMonth.split('-')[0]);
    const month = parseInt(filterMonth.split('-')[1]) - 1;
    
    // Days in this month
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const labels = [];
    const salesArr = [];
    const profitArr = [];
    const purchaseArr = [];

    for (let day = 1; day <= daysInMonth; day++) {
      labels.push(day.toString());
      
      const dStart = new Date(year, month, day, 0, 0, 0, 0);
      const dEnd = new Date(year, month, day, 23, 59, 59, 999);

      // sales
      const daySales = sales.filter(s => {
        const sDate = new Date(s.date);
        return sDate >= dStart && sDate <= dEnd;
      });
      salesArr.push(daySales.reduce((sum, s) => sum + s.total, 0));
      profitArr.push(daySales.reduce((sum, s) => sum + s.profit, 0));

      // purchases
      const dayPurchases = purchases.filter(p => {
        const pDate = new Date(p.date);
        return pDate >= dStart && pDate <= dEnd;
      });
      purchaseArr.push(dayPurchases.reduce((sum, p) => sum + p.total, 0));
    }

    if (state.charts.monthlyPerfChart) {
      state.charts.monthlyPerfChart.destroy();
    }

    const ctx = document.getElementById('report-performance-chart').getContext('2d');
    state.charts.monthlyPerfChart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Sales Revenue',
            data: salesArr,
            borderColor: '#3b82f6',
            backgroundColor: 'rgba(59, 130, 246, 0.05)',
            tension: 0.3,
            fill: true
          },
          {
            label: 'Profit Margin',
            data: profitArr,
            borderColor: '#10b981',
            backgroundColor: 'rgba(16, 185, 129, 0.05)',
            tension: 0.3,
            fill: true
          },
          {
            label: 'Purchase Outflow',
            data: purchaseArr,
            borderColor: '#f43f5e',
            backgroundColor: 'rgba(244, 63, 94, 0.05)',
            tension: 0.3,
            fill: true
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { labels: { color: '#94a3b8' } }
        },
        scales: {
          x: {
            title: { display: true, text: 'Day of Month', color: '#94a3b8' },
            ticks: { color: '#94a3b8' },
            grid: { color: 'rgba(255, 255, 255, 0.05)' }
          },
          y: {
            ticks: { color: '#94a3b8' },
            grid: { color: 'rgba(255, 255, 255, 0.05)' }
          }
        }
      }
    });
  }

  function renderCategoryStockChart(products, stock) {
    const categoryQty = { new: 0, used: 0, keypad: 0, accessory: 0 };
    
    products.forEach(p => {
      const qty = stock[p.id] || 0;
      if (categoryQty[p.type] !== undefined) {
        categoryQty[p.type] += qty;
      }
    });

    if (state.charts.categoryChart) {
      state.charts.categoryChart.destroy();
    }

    const ctx = document.getElementById('report-category-chart').getContext('2d');
    state.charts.categoryChart = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['New Mobiles', 'Used Mobiles', 'Keypad Mobiles', 'Accessories'],
        datasets: [{
          data: [categoryQty.new, categoryQty.used, categoryQty.keypad, categoryQty.accessory],
          backgroundColor: ['#3b82f6', '#8b5cf6', '#f59e0b', '#10b981'],
          borderWidth: 0
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'right',
            labels: { color: '#94a3b8' }
          }
        }
      }
    });
  }

  function renderTopSellingChart(sales, products) {
    const productSales = {};
    sales.forEach(sale => {
      sale.items.forEach(item => {
        productSales[item.productId] = (productSales[item.productId] || 0) + item.qty;
      });
    });

    const list = products
      .map(p => ({
        name: p.name,
        qty: productSales[p.id] || 0
      }))
      .filter(item => item.qty > 0)
      .sort((a,b) => b.qty - a.qty)
      .slice(0, 5);

    if (state.charts.topSellChart) {
      state.charts.topSellChart.destroy();
    }

    const ctx = document.getElementById('report-topselling-chart').getContext('2d');
    state.charts.topSellChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: list.map(item => item.name.length > 15 ? item.name.substring(0, 15) + '..' : item.name),
        datasets: [{
          label: 'Quantity Sold',
          data: list.map(item => item.qty),
          backgroundColor: '#8b5cf6',
          borderRadius: 8
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: { ticks: { color: '#94a3b8' }, grid: { display: false } },
          y: { ticks: { color: '#94a3b8' }, grid: { color: 'rgba(255, 255, 255, 0.05)' } }
        }
      }
    });
  }

  function renderTopSellingReportTable(sales, products) {
    const productSales = {};
    const productProfit = {};
    
    sales.forEach(sale => {
      sale.items.forEach(item => {
        productSales[item.productId] = (productSales[item.productId] || 0) + item.qty;
        
        const lineProfit = (item.price - item.cost) * item.qty;
        productProfit[item.productId] = (productProfit[item.productId] || 0) + lineProfit;
      });
    });

    const list = products
      .map(p => ({
        product: p,
        qty: productSales[p.id] || 0,
        profit: productProfit[p.id] || 0
      }))
      .filter(item => item.qty > 0)
      .sort((a,b) => b.qty - a.qty);

    elements.reportTopProductsTable.innerHTML = '';

    if (list.length === 0) {
      elements.reportTopProductsTable.innerHTML = `
        <tr>
          <td colspan="5" class="text-muted" style="text-align: center; padding: 1.5rem;">
            No sales recorded in this month.
          </td>
        </tr>
      `;
      return;
    }

    list.forEach((item, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>#${idx + 1}</strong></td>
        <td>${item.product.name}</td>
        <td>${item.product.brand}</td>
        <td>${item.qty}</td>
        <td style="font-weight:600; color:var(--accent-emerald);">Rs. ${item.profit.toLocaleString(undefined, {minimumFractionDigits: 0})}</td>
      `;
      elements.reportTopProductsTable.appendChild(tr);
    });
  }

  // ==========================================
  // INITIALIZATION ON LOAD
  // ==========================================
  // Set default month input value to current year-month (YYYY-MM)
  const now = new Date();
  const yearMonth = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  elements.reportFilterMonth.value = yearMonth;

  checkAuth();
});

// ==========================================
// BILLING TABS LOGIC
// ==========================================
document.addEventListener('click', (e) => {
  const tabBtn = e.target.closest('.billing-tab-btn');
  if (tabBtn) {
    // Remove active class from all tabs
    document.querySelectorAll('.billing-tab-btn').forEach(btn => btn.classList.remove('active'));
    // Add to clicked
    tabBtn.classList.add('active');

    // Remove active class from all panes
    document.querySelectorAll('.billing-tab-pane').forEach(pane => pane.classList.remove('active'));
    
    // Activate target pane
    const targetId = `billing-tab-${tabBtn.dataset.tab}`;
    const targetPane = document.getElementById(targetId);
    if (targetPane) targetPane.classList.add('active');
  }
});

// Update cart badge using MutationObserver since app.js state is encapsulated
setTimeout(() => {
  const cartContainer = document.getElementById('cart-items-container');
  if (cartContainer) {
    const observer = new MutationObserver(() => {
      const rowCount = cartContainer.querySelectorAll('.cart-item').length;
      const badge = document.getElementById('cart-badge');
      if (badge) badge.textContent = rowCount;
    });
    observer.observe(cartContainer, { childList: true, subtree: true });
  }
}, 1000);
