@echo off
title FaizanKiShop Background Server

:: Start the local web server silently in the background
start /B python -m http.server 8080 >nul 2>&1

:: Wait 2 seconds for server to start
timeout /t 2 /nobreak >nul

:: Launch Microsoft Edge in "App Mode" (looks like a native desktop app without browser tabs)
start "" "msedge.exe" --app="http://localhost:8080"

:: Exit the command prompt
exit
